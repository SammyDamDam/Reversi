package yao.samantha;

import java.util.Scanner;
import java.util.Random;

public class ReversiDriver {

	public static void main(String[] args) {
		Board board = new Board();
		Random rn = new Random();
		Scanner in = new Scanner(System.in);
		boolean gameOver = false;

		System.out.println("Welcome to Reversi");
		System.out.println("To play, enter coordinates on separate lines");
		board.displayBoard();
		checkGameOver(gameOver, board);
		
		int aiX = rn.nextInt(8);
		int aiY = rn.nextInt(8);
		boolean isPlayerTurn = true;
		boolean isAITurn = false;
		
		while (!gameOver) {
			System.out.println("Your Turn");
			while (isPlayerTurn) {
				int playerX = getInt(in, "X-coordinate:");
				int playerY = getInt(in, "Y-coordinate:");
				if (board.flip(playerX, playerY, CellState.PLAYER, false)) {
					board.flip(playerX, playerY, CellState.PLAYER, true);
					board.placePiece(playerX, playerY, CellState.PLAYER);
					isPlayerTurn = false;
					isAITurn = true;
				} else {
					System.out.println("Invalid move. Try again.");
				}
				board.displayBoard();
				checkGameOver(gameOver, board);
			}
			System.out.println("CPU's Turn");
			while (isAITurn) {
				if (board.flip(aiX, aiY, CellState.AI, false)) {

					board.flip(aiX, aiY, CellState.AI, true);
					board.placePiece(aiX, aiY, CellState.AI);
					isPlayerTurn = true;
					isAITurn = false;
					board.displayBoard();
					checkGameOver(gameOver, board);
				} else {
					aiX = rn.nextInt(8);
					aiY = rn.nextInt(8);
				}

			}

		}
		int[] score = board.getScore();
		System.out.printf("The final score is You: %d  AI: %d%n", score[0], score[1]);
		if (score[0] > score[1]) {
			System.out.println("Congratulations, you win!");
		} else if (score[1] > score[0]) {
			System.out.println("Defeat!");
		} else {
			System.out.println("Tie!");
		}

	}

	/**
	 * Checks if the game is over by checking if there are any blank spaces on
	 * the board, I\if there are no empty slots on the board, the game is over
	 * Also calculates and displays the score
	 * 
	 * @param gameOver
	 *            boolean true if the game is over
	 * @param board
	 *            a Board object to check if the board is full
	 */
	public static void checkGameOver(boolean gameOver, Board board) {
		int[] score = board.getScore();
		System.out.printf("You: %d  AI: %d%n", score[0], score[1]);
		boolean hasSpace = false;
		for (int i = 0; i < 8; i++) {
			for (int j = 0; i < 8; i++) {
				if (board.getBoard()[i][j].getState() == CellState.EMPTY) {
					hasSpace = true;
				}
			}
		}
		if (!hasSpace) {
			gameOver = true;
		}
	}

	public static int getInt(Scanner input, String prompt) {
		boolean valid = false;
		int x = 66;
		while (!valid) {
			System.out.println(prompt);
			if (input.hasNextInt()) {
				x = input.nextInt();
				if (x < 8) {
					valid = true;
				} else {
					System.out.println("Coordinate not within range of board");
				}
			} else {
				input.nextLine();
				System.out.println("Not a valid integer. Try again.");
			}
		}
		return x;
	}

}
