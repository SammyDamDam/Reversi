package yao.samantha;

import java.util.Scanner;

public class ReversiDriver {

	public static void main(String[] args) {
		Board board = new Board();
		Scanner in = new Scanner(System.in);
		boolean gameOver = false;

		System.out.println("Welcome to Reversi");
		System.out.println("To play, enter coordinates on separate lines");
		board.displayBoard();
		while (!gameOver) {

			System.out.println("Your Turn");
			int x = getInt(in, "X-coordinate:");
			int y = getInt(in, "Y-coordinate:");
			board.getBoard()[x][y].setState(CellState.PLAYER);
			board.displayBoard();
			System.out.println("CPU's Turn");
			// call some AI method
			board.displayBoard();
		}

	}

	public static int getInt(Scanner input, String prompt) {
		boolean valid = false;
		int x = 66;
		while (!valid) {
			System.out.println(prompt);
			if (input.hasNextInt()) {
				x = input.nextInt();
				valid = true;
			} else {
				input.nextLine();
				System.out.println("Not a valid integer. Try again.");
			}
		}
		return x;
	}

}
