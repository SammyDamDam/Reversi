package yao.samantha;

/**
 * This class creates a Board object
 * 
 * @author yaosa
 *
 */
public class Board {
	private Cell[][] board;

	/**
	 * Creates a new 8 x 8 board for Reversi, a 2D array of type Cell Sets the
	 * initial default pieces (2 AI and 2 PLAYER)
	 */
	public Board() {
		board = new Cell[8][8];
		for (int i = 0; i < 8; i++) {
			for (int j = 0; j < 8; j++) {
				board[i][j] = new Cell(CellState.EMPTY);
			}
		}
		board[3][3].setState(CellState.AI);
		board[3][4].setState(CellState.PLAYER);
		board[4][3].setState(CellState.PLAYER);
		board[4][4].setState(CellState.AI);
	}

	/**
	 * 
	 * @return board
	 */
	public Cell[][] getBoard() {
		return board;
	}

	/**
	 * Prints the board in the console
	 */
	public void displayBoard() {
		System.out.println("BOARD");
		for (int i = 0; i < 8; i++) {
			for (int j = 0; j < 8; j++) {
				System.out.printf("%s ", board[i][j]);
			}
			System.out.println();
		}
	}

}
