package yao.samantha;

public class Board {
	private Cell[][] board;

	public Board() {
		board = new Cell[8][8];
		for (int i = 0; i < 8; i++) {
			for (int j = 0; j < 8; j++) {
				board[i][j] = new Cell(CellState.EMPTY);
			}
		}
		board[3][3].setState(CellState.AI);
		board[3][4].setState(CellState.PLAYER);
		board[4][3].setState(CellState.PLAYER);
		board[4][4].setState(CellState.AI);
		setPossibilities(CellState.AI);
	}

	public void displayBoard() {
		System.out.println("BOARD");
		for (int i = 0; i < 8; i++) {
			for (int j = 0; j < 8; j++) {
				System.out.printf("%s ", board[i][j]);
			}
			System.out.println();
		}
	}

	public void setPossibilities(CellState cs) {
		for (int i = 0; i < 8; i++) {
			for (int j = 0; j < 8; j++) {
				if (board[i][j].getState() == cs) {
					for (int m = 0;m<7;m++){
						if (board[i][m] == )
					}
				}
			}
		}
	}
}
