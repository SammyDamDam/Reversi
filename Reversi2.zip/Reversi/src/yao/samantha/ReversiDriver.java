package yao.samantha;

import java.util.Scanner;

public class ReversiDriver {

	public static void main(String[] args) {
		Board board = new Board();

		board.displayBoard();
		System.out.println("Your Turn");

	}

	public static int getInt(Scanner input, String prompt) {
		boolean valid = false;
		int x = 66;
		while (!valid) {
			System.out.println(prompt);
			if (input.hasNextInt()) {
				x = input.nextInt();
				valid = true;
			} else {
				input.nextLine();
				System.out.println("Not a valid integer. Try again.");
			}
		}
		return x;
	}

}
