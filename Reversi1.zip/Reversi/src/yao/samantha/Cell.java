package yao.samantha;

public class Cell {
	private CellState cellstate;

	public Cell(CellState cs) {
		cellstate = cs;
	}

	public void setState(CellState cs) {
		cellstate = cs;
	}

	public CellState getState() {
		return cellstate;
	}

	public String toString() {
		switch (cellstate) {
		case EMPTY:
			return "0";
		case PLAYER:
			return "1";
		case AI:
			return "2";
		default:
			return "-";
		}
	}

}
