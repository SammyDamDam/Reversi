package yao.samantha;

public class ReversiDriver {

	public static void main(String[] args) {
		Board board = new Board();
		
		board.displayBoard();

	}

}
