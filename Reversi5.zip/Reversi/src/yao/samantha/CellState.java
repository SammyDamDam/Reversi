package yao.samantha;

public enum CellState {
	EMPTY, PLAYER, AI
}
