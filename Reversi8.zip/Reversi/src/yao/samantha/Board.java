package yao.samantha;

/**
 * This class creates a Board object
 * 
 * @author yaosa
 *
 */
public class Board {
	private Cell[][] board;

	/**
	 * Creates a new 8 x 8 board for Reversi, a 2D array of type Cell Sets the
	 * initial default pieces (2 AI and 2 PLAYER)
	 */
	public Board() {
		board = new Cell[8][8];
		for (int i = 0; i < 8; i++) {
			for (int j = 0; j < 8; j++) {
				board[i][j] = new Cell(CellState.EMPTY);
			}
		}
		board[3][3].setState(CellState.AI);
		board[3][4].setState(CellState.PLAYER);
		board[4][3].setState(CellState.PLAYER);
		board[4][4].setState(CellState.AI);
	}

	/**
	 * 
	 * @return board
	 */
	public Cell[][] getBoard() {
		return board;
	}
/**
 * Places a piece on the board
 * @param x x-coordinate of where the piece will be placed
 * @param y y-coordinate of where the piece will be placed
 * @param cs CellState of the piece
 */
	public void placePiece(int x, int y, CellState cs) {
		if (board[x][y].getState() == CellState.EMPTY) {
			board[x][y].setState(cs);
		}
	}

	public boolean flip(int row, int col, CellState piece, boolean putDown) {
		boolean isValid = false;
		for (int dX = -1; dX < 2; dX++) {
			for (int dY = -1; dY < 2; dY++) {
				if (dX == 0 && dY == 0) {
					continue;
				}
				int checkRow = row + dX;
				int checkCol = col + dY;
				if (checkRow >= 0 && checkCol >= 0 && checkRow < 8 && checkCol < 8) {
					if (board[checkRow][checkCol]
							.getState() == (piece == CellState.PLAYER ? CellState.AI : CellState.PLAYER)) {
						for (int distance = 0; distance < 8; distance++) {
							int minorCheckRow = row + distance * dX;
							int minorCheckCol = col + distance * dY;
							if (minorCheckRow < 0 || minorCheckCol < 0 || minorCheckRow > 7 || minorCheckCol > 7)
								continue;
							if (board[minorCheckRow][minorCheckCol] == board[row][col]) {
								if (putDown) {
									for (int distance2 = 1; distance2 < distance; distance2++) {
										int flipRow = row + distance2 * dX;
										int flipCol = col + distance2 * dY;
										board[flipRow][flipCol] = board[row][col];
									}
								}
								isValid = true;
								break;
							}
						}
					}
				}
			}
		}
		return isValid;
	}

	public int[] getScore() {
		int scorePlayer = 0;
		int scoreAI = 0;
		for (int i = 0; i < 8; i++) {
			for (int j = 0; j < 8; j++) {
				if (board[i][j].getState() == CellState.PLAYER) {
					scorePlayer++;
				} else if (board[i][j].getState() == CellState.AI) {
					scoreAI++;
				}
			}
		}
		int[] score = { scorePlayer, scoreAI };
		return score;
	}

	/**
	 * Prints the board in the console
	 */
	public void displayBoard() {
		System.out.println("BOARD");
		for (int i = 0; i < 8; i++) {
			for (int j = 0; j < 8; j++) {
				System.out.printf("%s ", board[i][j]);
			}
			System.out.println();
		}
	}

}
