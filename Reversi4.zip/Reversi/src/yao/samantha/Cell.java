package yao.samantha;

/**
 * This class creates a Cell object
 * 
 * @author yaosa
 *
 */
public class Cell {
	private CellState cellstate;

	public Cell(CellState cs) {
		cellstate = cs;
	}

	/**
	 * 
	 * @param cs
	 *            the state to which the Cell should be set
	 */
	public void setState(CellState cs) {
		cellstate = cs;
	}

	public CellState getState() {
		return cellstate;
	}

	public CellState getOppositeState(CellState cs) {
		switch (cs) {
		case PLAYER:
			return CellState.AI;
		case AI:
			return CellState.PLAYER;
		default:
			return CellState.EMPTY;
		}
	}

	public String toString() {
		switch (cellstate) {
		case EMPTY:
			return "0";
		case PLAYER:
			return "1";
		case AI:
			return "2";
		case POSSIBLEAI:
			return "A";
		case POSSIBLEPLAYER:
			return "P";
		default:
			return "-";
		}
	}

}
